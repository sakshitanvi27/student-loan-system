from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

from rest_framework.routers import DefaultRouter
from rest_framework_simplejwt.views import TokenRefreshView

from .views import (
    SignupView,
    loginUser,
    MyTokenObtainPairView,
    LoanListView,
    LoanApplicationViewSet,
    MyLoansView,
    DeleteLoanView,
    userProfile,
    LoanResultView,
    LoanAnalyzeAPIView,
    PredictLoanAPIView,
    bank_applications,
    update_application_status,
)

# ================= ROUTER =================
router = DefaultRouter()
router.register(r'applications', LoanApplicationViewSet, basename='applications')

# ================= URL PATTERNS =================
urlpatterns = [
    # -------- AUTH --------
    path('signup/', SignupView.as_view(), name='signup'),
    path('login/', loginUser, name='login'),
    path('token/', MyTokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),

    # -------- LOANS --------
    path('loans/', LoanListView.as_view(), name='loan-list'),

    # -------- USER --------
    path('profile/', userProfile, name='profile'),
    path('my-loans/', MyLoansView.as_view(), name='my-loans'),
    path('delete-loan/<int:pk>/', DeleteLoanView.as_view(), name='delete-loan'),

    # -------- AI / ANALYSIS --------
    path('loan-result/<int:pk>/', LoanResultView.as_view(), name='loan-result'),
    path('loan-analyze/<int:pk>/', LoanAnalyzeAPIView.as_view(), name='loan-analyze'),
    path('predict/', PredictLoanAPIView.as_view(), name='predict-loan'),

    # -------- BANK --------
    path('bank/applications/', bank_applications),
    path('bank/applications/<int:pk>/status/', update_application_status),

    # -------- APPLICATIONS (VIEWSET) --------
    path('', include(router.urls)),
]

# ================= MEDIA =================
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
